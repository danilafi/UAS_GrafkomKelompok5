function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
}

function draw() {
	circle(mouseX, mouseY, 20);
}let gameState = "home";
let score = 0;
let plasticSpeed = 2;
let obstacles = [];
let turtle;
let itemShopItems = [
  { emoji: "🐢", name: "Turtle", cost: 0 },
  { emoji: "🐠", name: "Fish", cost: 50 },
  { emoji: "🐬", name: "Dolphin", cost: 100 },
  { emoji: "🐳", name: "Whale", cost: 300 }
];
let equippedItem = itemShopItems[0];
let selectedItem = null;

const buttonWidth = 120;
const buttonHeight = 40;

function setup() {
  createCanvas(400, 400);
  resetGame();
}

function draw() {
  background(0);

  if (gameState === "home") {
    displayHomeScreen();
  } else if (gameState === "game") {
    gamePlay();
  } else if (gameState === "gameover") {
    displayGameOver();
  } else if (gameState === "itemshop") {
    displayItemShop();
  } else if (gameState === "difficulty") {
    displayDifficultyPage();
  }

  prevMouseState = mouseIsPressed;
}

function displayHomeScreen() {
  background(0);

  textAlign(CENTER, CENTER);
  textSize(48);
  fill(0, 191, 255);
  text("Turtle Game", width / 2, height / 2 - 80);

  if (button(width / 2, height / 2 - 20, "Play")) {
    resetGame();
    gameState = "game";
  }

  if (button(width / 2, height / 2 + 40, "Shop")) {
    gameState = "itemshop";
  }

  if (button(width / 2, height / 2 + 100, "Difficulty")) {
    gameState = "difficulty";
  }
}

function displayDifficultyPage() {
  background(0);

  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0, 191, 255);
  text("Difficulty", width / 2, 60);

  let difficulties = ["Easy", "Medium", "Hard"];
  let selectedDifficulty = customSelect(difficulties, "Select a difficulty");

  if (selectedDifficulty) {
    if (selectedDifficulty === "Easy") {
      plasticSpeed = 2;
    } else if (selectedDifficulty === "Medium") {
      plasticSpeed = 4;
    } else if (selectedDifficulty === "Hard") {
      plasticSpeed = 6;
    }

    gameState = "home";
  }
}

function gamePlay() {
  background(0, 0, 255);

  turtle.update();
  turtle.display();

  if (frameCount % 60 === 0) {
    score++;
  }

  if (frameCount % 30 === 0) {
    obstacles.push(new Plastic());
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    let obstacle = obstacles[i];
    obstacle.update();
    obstacle.display();

    if (turtle.hits(obstacle)) {
      gameState = "gameover";
    }

    if (obstacle.offscreen()) {
      obstacles.splice(i, 1);
    }
  }

  textSize(24);
  fill(255);
  text("Score: " + score, width / 2, 30);
}

function displayGameOver() {
  background(0);

  textAlign(CENTER, CENTER);
  textSize(32);
  fill(255);
  text("Game Over", width / 2, height / 2 - 50);

  textSize(24);
  text("Score: " + score, width / 2, height / 2);

  if (button(width / 2, height / 2 + 60, "Restart")) {
    resetGame();
    gameState = "game";
  }

  if (button(width / 2, height / 2 + 120, "Home")) {
    gameState = "home";
  }
}

function displayItemShop() {
  background(0);

  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0, 191, 255);
  text("Item Shop", width / 2, 60);

  let yPos = 120;
  for (let i = 0; i < itemShopItems.length; i++) {
    let item = itemShopItems[i];

    fill(255);
    textSize(32);
    text(item.emoji, width / 2 - 50, yPos);

    textSize(20);
    if (equippedItem === item) {
      text("Equipped", width / 2 + 30, yPos);
    } else if (score >= item.cost) {
      if (button(width / 2 + 30, yPos, "Buy")) {
        score -= item.cost;
        equippedItem = item;
      }
    } else {
      text("Cost: " + item.cost, width / 2 + 30, yPos);
    }

    yPos += 60;
  }

  if (button(width / 2, height - 60, "Back")) {
    gameState = "home";
  }
}

function resetGame() {
  score = 0;
  obstacles = [];
  turtle = new Turtle();
}

function button(x, y, label) {
  let buttonClicked = false;

  let buttonColor = color(100);
  let textColor = color(255);
  let buttonHovered = false;

  if (
    mouseX >= x - buttonWidth / 2 &&
    mouseX <= x + buttonWidth / 2 &&
    mouseY >= y - buttonHeight / 2 &&
    mouseY <= y + buttonHeight / 2
  ) {
    buttonHovered = true;
    buttonColor = color(150);
  }

  if (buttonHovered && mouseIsPressed) {
    buttonColor = color(200);
  }

  fill(buttonColor);
  stroke(0);
  rectMode(CENTER);
  rect(x, y, buttonWidth, buttonHeight, 5);

  fill(textColor);
  textSize(18);
  textAlign(CENTER, CENTER);
  text(label, x, y);

  if (buttonHovered && !mouseIsPressed && mouseIsPressed !== prevMouseState) {
    buttonClicked = true;
  }

  return buttonClicked;
}

function customSelect(options, label) {
  let dropdownX = width / 2;
  let dropdownY = height / 2;
  let dropdownWidth = 200;
  let dropdownHeight = 30;
  let itemHeight = 30;

  let isOpen = false;
  let selectedOption = null;

  let dropdownHovered = mouseX >= dropdownX - dropdownWidth / 2 &&
    mouseX <= dropdownX + dropdownWidth / 2 &&
    mouseY >= dropdownY - dropdownHeight / 2 &&
    mouseY <= dropdownY + dropdownHeight / 2;

  if (dropdownHovered && mouseIsPressed && !prevMouseState) {
    isOpen = !isOpen;
  }

  fill(255);
  stroke(0);
  rectMode(CENTER);
  rect(dropdownX, dropdownY, dropdownWidth, dropdownHeight, 5);

  fill(0);
  textSize(16);
  textAlign(CENTER, CENTER);
  text(label, dropdownX, dropdownY);

  if (isOpen) {
    for (let i = 0; i < options.length; i++) {
      let optionX = dropdownX;
      let optionY = dropdownY + dropdownHeight / 2 + itemHeight * (i + 1);

      let optionHovered = mouseX >= optionX - dropdownWidth / 2 &&
        mouseX <= optionX + dropdownWidth / 2 &&
        mouseY >= optionY - itemHeight / 2 &&
        mouseY <= optionY + itemHeight / 2;

      if (optionHovered && mouseIsPressed && !prevMouseState) {
        selectedOption = options[i];
        isOpen = false;
        break;
      }

      fill(255);
      textSize(16);
      textAlign(CENTER, CENTER);
      text(options[i], optionX, optionY);
    }
  }

  return selectedOption;
}

class Turtle {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 50;
    this.speed = 4;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  display() {
    textSize(this.size);
    fill(255);
    text(equippedItem.emoji, this.x, this.y);
  }

  hits(obstacle) {
    let distance = dist(this.x, this.y, obstacle.x, obstacle.y);
    return distance < this.size / 2 + obstacle.size / 2;
  }
}

class Plastic {
  constructor() {
    this.size = random(20, 40);
    this.x = random() > 0.5 ? -this.size / 2 : width + this.size / 2;
    this.y = random(height);
    this.xSpeed = random(-plasticSpeed, plasticSpeed);
    this.ySpeed = random(-plasticSpeed, plasticSpeed);
  }

  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;
  }

  display() {
    textSize(this.size);
    fill(255);
    text("🥤", this.x, this.y);
  }

  offscreen() {
    return (
      this.x < -this.size / 2 ||
      this.x > width + this.size / 2 ||
      this.y < -this.size / 2 ||
      this.y > height + this.size / 2
    );
  }
}
