function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);
}
function draw() {
  circle(mouseX, mouseY, 20);
}

//////////////////////ITEM
let gameState = "home";
let score = 0;
let plasticSpeed = 2;
let obstacles = [];
let hero;
let itemShopItems = [
  { emoji: "👾", name: "Alien", cost: 0 },     // U+1F47E (Alien Monster)
  { emoji: "👽", name: "Alien", cost: 50 },    // U+1F47D (Extraterrestrial Alien)
  { emoji: "👻", name: "Ghost", cost: 100 },   // U+1F47B (Ghost)
  { emoji: "🤖", name: "Robot", cost: 300 }    // U+1F916 (Robot Face)
];
let equippedItem = itemShopItems[0];
let selectedItem = null;
const buttonWidth = 130;
const buttonHeight = 45;


//////////SETUP
function setup() {
  createCanvas(900, 500);
  resetGame();
}


//////////BAGROUND
function draw() {
  background(0);
  if (gameState === "home") {
    displayHomeScreen();
  } else if (gameState === "game") {
    gamePlay();
  } else if (gameState === "gameover") {
    displayGameOver();
  } else if (gameState === "itemshop") {
    displayItemShop();
  } else if (gameState === "difficulty") {
    displayDifficultyPage();
  }
  prevMouseState = mouseIsPressed;
}


///////////HOME SCREEN
function displayHomeScreen() {
  // Tampilan game
  background(150, 230, 240); //Atas
  noStroke();
  fill(100, 200, 75); //Bawah
  rect(width / 2, 450, width, 100);
  textAlign(CENTER, CENTER);
  textSize(35);
  fill(28,30, 73);
  text("SCORE FINDER", width / 2, height / 2 - 150);
  textSize(35);
  fill(28, 30, 73);
  text("GAME", width / 2, height / 2 - 100);
  textSize(20);
  fill(255, 255,0);
  text("UAS GRAFIKA KOMPUTER", width / 2, height - 70);
  textSize(20);
  fill(255, 255,0);
  text("21104410074 | 21104410082 | 21104410084", width / 2, height - 30);
  if (button(width / 2, height / 2 - 10, "Play")) {
    resetGame();
    gameState = "game";
  }
  if (button(width / 2, height / 2 + 80, "Shop")) {
    gameState = "itemshop";
  }
}


///////////GAME PLAY
function gamePlay() {
  background(184, 212, 238);

  hero.update();
  hero.display();
  if (frameCount % 60 === 0) {
    score++;
  }
  if (frameCount % 30 === 0) {
    obstacles.push(new Plastic());
  }
  for (let i = obstacles.length - 1; i >= 0; i--) {
    let obstacle = obstacles[i];
    obstacle.update();
    obstacle.display();
    if (hero.hits(obstacle)) {
      gameState = "gameover";
    }
    if (obstacle.offscreen()) {
      obstacles.splice(i, 1);
    }
  }
  textSize(24);
  fill(55, 10, 255);
  text("Score: " + score, width / 2, 30);
}


////////////GAME OVER
function displayGameOver() {
   // Tampilan game
  background(150, 230, 240); //Atas
  noStroke();
  fill(100, 200, 75); //Bawah
  rect(width / 2, 450, width, 100);
  textAlign(CENTER, CENTER);
  textSize(40);
  fill(4, 31, 52);
  text("Game Over", width / 2, height / 2 - 90);
  textSize(30);
  text("Score: " + score, width / 2, height / 2 - 50);

  if (button(width / 2, height / 2 + 40, "Restart")) {
    resetGame();
    gameState = "game";
  }
  if (button(width / 2, height / 2 + 100, "Home")) {
    gameState = "home";
  }
  
  textSize(20);
  fill(4, 31, 52);
  text("Danila | Alya | Berlian", width / 2, height - 50);
}


////////ITEM SHOP
function displayItemShop() {
  background(0);
  textAlign(CENTER, CENTER);
  textSize(40);
  fill(0, 191, 255);
  text("Items Space", width / 2, 60);
  let yPos = 120;
  for (let i = 0; i < itemShopItems.length; i++) {
    let item = itemShopItems[i];
    fill(255);
    textSize(32);
    text(item.emoji, width / 2 - 50, yPos);
    textSize(20);
    if (equippedItem === item) {
      text("Equipped", width / 2 + 30, yPos);
    } else if (score >= item.cost) {
      if (button(width / 2 + 30, yPos, "Buy")) {
        score -= item.cost;
        equippedItem = item;
      }
    } else {
      text("Cost: " + item.cost, width / 2 + 30, yPos);
    }
    yPos += 60;
  }
  if (button(width / 2, height - 140, "Back")) {
    gameState = "home";
  }
  textSize(20);
  fill(254, 254, 254);
  text("Danila | Alya | Berlian", width / 2, height - 50);
}

function resetGame() {
  score = 0;
  obstacles = [];
  hero = new Hero(); 
}

////////PERGERAKAN
function button(x, y, label) {
  let buttonClicked = false;
  let buttonColor = color(100);
  let textColor = color(255);
  let buttonHovered = false;
  if (
    mouseX >= x - buttonWidth / 2 &&
    mouseX <= x + buttonWidth / 2 &&
    mouseY >= y - buttonHeight / 2 &&
    mouseY <= y + buttonHeight / 2
  ) {
    buttonHovered = true;
    buttonColor = color(150);
  }
  if (buttonHovered && mouseIsPressed) {
    buttonColor = color(200);
  }
  fill(buttonColor);
  stroke(0);
  rectMode(CENTER);
  rect(x, y, buttonWidth, buttonHeight, 5);

  fill(textColor);
  textSize(18);
  textAlign(CENTER, CENTER);
  text(label, x, y);

  if (buttonHovered && !mouseIsPressed && mouseIsPressed !== prevMouseState) {
    buttonClicked = true;
  }
  return buttonClicked;
}


//////////////////HERO /KARAKTER
function customSelect(options, label) {
  let dropdownX = width / 2;
  let dropdownY = height / 2;
  let dropdownWidth = 200;
  let dropdownHeight = 30;
  let itemHeight = 30;
  let isOpen = false;
  let selectedOption = null;

  let dropdownHovered = mouseX >= dropdownX - dropdownWidth / 2 &&
    mouseX <= dropdownX + dropdownWidth / 2 &&
    mouseY >= dropdownY - dropdownHeight / 2 &&
    mouseY <= dropdownY + dropdownHeight / 2;
  if (dropdownHovered && mouseIsPressed && !prevMouseState) {
    isOpen = !isOpen;
  }
  fill(255);
  stroke(0);
  rectMode(CENTER);
  rect(dropdownX, dropdownY, dropdownWidth, dropdownHeight, 5);
  fill(0);
  textSize(16);
  textAlign(CENTER, CENTER);
  text(label, dropdownX, dropdownY);
  if (isOpen) {
    for (let i = 0; i < options.length; i++) {
      let optionX = dropdownX;
      let optionY = dropdownY + dropdownHeight / 2 + itemHeight * (i + 1);
      let optionHovered = mouseX >= optionX - dropdownWidth / 2 &&
        mouseX <= optionX + dropdownWidth / 2 &&
        mouseY >= optionY - itemHeight / 2 &&
        mouseY <= optionY + itemHeight / 2;

      if (optionHovered && mouseIsPressed && !prevMouseState) {
        selectedOption = options[i];
        isOpen = false;
        break;
      }

      fill(255);
      textSize(16);
      textAlign(CENTER, CENTER);
      text(options[i], optionX, optionY);
    }
  }
  return selectedOption;
}
class Hero { 
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 50;
    this.speed = 4;
  }
  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }
  display() {
    textSize(this.size);
    fill(255);
    text(equippedItem.emoji, this.x, this.y);
  }
  hits(obstacle) {
    let distance = dist(this.x, this.y, obstacle.x, obstacle.y);
    return distance < this.size / 2 + obstacle.size / 2;
  }
}

///////RINTANGAN
class Plastic {
  constructor() {
    this.size = random(20, 40);
    this.x = random() > 0.5 ? -this.size / 2 : width + this.size / 2;
    this.y = random(height);
    this.xSpeed = random(-plasticSpeed, plasticSpeed);
    this.ySpeed = random(-plasticSpeed, plasticSpeed);
  }
  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;
  }
  display() {
    textSize(this.size);
    fill(255);
    text("👹", this.x, this.y); 
  }
  offscreen() {
    return (
      this.x < -this.size / 2 ||
      this.x > width + this.size / 2 ||
      this.y < -this.size / 2 ||
      this.y > height + this.size / 2
    );
  }
}